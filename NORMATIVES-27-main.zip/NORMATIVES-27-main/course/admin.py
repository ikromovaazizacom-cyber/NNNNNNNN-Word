from django.contrib import admin
from course.models import Course

admin.site.register(Course)
# Register your models here.
